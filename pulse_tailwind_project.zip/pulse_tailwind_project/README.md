# Pulse Protocol (Tailwind + Vite)

## Быстрый старт
1. `npm i`
2. `npm run dev`
