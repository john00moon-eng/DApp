import { createChart } from "lightweight-charts";
import signals from "./data/mockSignals.json";

const el = document.getElementById("tv-chart");
if (el) {
  const chart = createChart(el, {
    layout: { background: { type: "solid", color: "#0C0E14" }, textColor: "#E6E7ED", fontSize: 12 },
    grid: { vertLines: { color: "#282C3F" }, horzLines: { color: "#282C3F" } },
    rightPriceScale: { borderVisible: false },
    timeScale: { borderVisible: false }
  });

  const series = chart.addCandlestickSeries({
    upColor: "#46C078",
    downColor: "#DC5A78",
    wickUpColor: "#46C078",
    wickDownColor: "#DC5A78",
    borderVisible: false
  });

  const now = Math.floor(Date.now() / 1000);
  const HOUR = 3600;
  let price = 30000;
  const candles = Array.from({ length: 120 }, (_, i) => {
    const time = now - (120 - i) * HOUR;
    const open = price;
    const change = (Math.random() - 0.5) * 500;
    const close = open + change;
    const high = Math.max(open, close) + Math.random() * 120;
    const low  = Math.min(open, close) - Math.random() * 120;
    price = close;
    return { time, open, high, low, close };
  });

  series.setData(candles);

  const markers = signals.signals.map(s => ({
    time: s.time,
    position: s.type === "BUY" ? "belowBar" : "aboveBar",
    color: s.type === "BUY" ? "#46C078" : "#DC5A78",
    shape: s.type === "BUY" ? "arrowUp" : "arrowDown",
    text: `${s.type} (email sent)`
  }));
  series.setMarkers(markers);
}